<div>
    <a href="{{ URL::current();}}"><img alt="nederland-vlag" src="{{ asset('storage/images/nl_flag.png') }}" height="23"></a>
    <a href="?lang=en"><img alt="engelse-vlag" src="{{ asset('storage/images/en_flag.png') }}" height="23"></a>
    <a href="?lang=de"><img alt="duitse-vlag" src="{{ asset('storage/images/de_flag.png') }}" height="23"></a>
</div>
