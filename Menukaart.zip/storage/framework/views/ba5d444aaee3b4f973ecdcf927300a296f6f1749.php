<?php if($course->image != ''): ?> <div style="background-image: linear-gradient(180deg,#697353 0%,rgba(64,65,64,0.39) 100%),url('/storage/images/uploaded/<?php echo e($course->image); ?>');
			background-position: 50%;
    background-repeat: no-repeat;
    background-size: cover;
	z-index: -1;
    padding-bottom: 50px;"> <?php endif; ?>
<div class="bg-primary text-secondary card mb-3" id="<?php echo e(preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '_', $course->title($course->id)))); ?>">
    <h3 class="spacing"><?php echo e($course->title($course->id)); ?></h3>
</div>
<h6 class="spacing py-2 text-white"><?php echo e($course->sub_title($course->id)); ?></h6>
<?php if($side_info != null && $course->id == $side_info->maincourse()): ?>
    <div class="card-sub_title">
        <h6 class="title text-primary"><b><?php echo e($side_info->title); ?></b></h5>
        <h6 class="sub_title text-white"><?php echo e($side_info->sub_title); ?></h5>
    </div>
    <div class="sides row justify-content-center">
    <?php $__currentLoopData = $sides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 py-3">
            <div class="side"><?php echo e($side->title($side->id)); ?></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php echo $__env->renderEach('modules.sub_course', $course->sub_courses, 'sub_course'); ?>
<?php if($course->image != ''): ?></div> <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Menukaart\resources\views/modules/course.blade.php ENDPATH**/ ?>