<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Menu</title>

        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

        
        <link rel="stylesheet" href="/css/app.css" />
        <link rel="stylesheet" href="/css/admin.css" />


    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container crud-table p-3">
            <div class="form-group row">
                <form action="" class="col-10">
                    <select name="menu" class="form-control custom-select">
                        <option value="">Selecteer Category</option>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($menu->title); ?>" <?php if($menu->title == $current): ?>selected <?php endif; ?> class="optionParent"><?php echo e($menu->title); ?></option>
                                <?php $__currentLoopData = $menu->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($courses->title); ?>" <?php if($courses->title == $current): ?>selected <?php endif; ?> class="optionSubParent"><?php echo e($courses->title); ?></option>
                                    <?php $__currentLoopData = $courses->sub_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($sub_courses->title == ''): ?> <?php continue; ?> <?php endif; ?>
                                        <option value="<?php echo e($sub_courses->title); ?>" <?php if($sub_courses->title == $current): ?>selected <?php endif; ?> class="optionChild"><?php echo e($sub_courses->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>

                <div class="col-2 pl-0">
                    <?php echo $__env->make('editor.dish_modal', $menus, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="clearfix"></div>
            </div>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Categorie</th>
                        <th>Titel</th>
                        <th>Info</th>
                        <th>Prijs</th>
                        <th>Bier</th>
                        <th>Wijn</th>
                        <th>Vega</th>
                        <th>Saus</th>
                        <th width="280px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><b><?php echo e($item->category($item)); ?></b></td>
                        <?php
                            $title = $item->title($item->id);
                            $info = $item->info($item->id);
                        ?>
                        <td><b>NL:</b> <?php echo e($title->nl); ?> <b>EN:</b> <?php echo e($title->en); ?> <b>DE:</b> <?php echo e($title->de); ?> </td>
                        <td><b>NL:</b> <?php echo e($info->nl); ?> <b>EN:</b> <?php echo e($info->en); ?> <b>DE:</b> <?php echo e($info->de); ?> </td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->title($item->id)->nl); ?></td>
                        <td><?php echo e($item->title($item->id)->nl); ?></td>
                        <td><?php echo e($item->vegan); ?></td>
                        <td><?php echo e($item->sauce); ?></td>
                        <td>
                            <?php if($item->toggle == 1): ?>
                                <a href="<?php echo e(route( 'toggle' , ['id' => $item->id, 'type' => 'dish'] )); ?>" type="submit" class="btn btn-success"><i class="fa-solid fa-eye"></i></a>
                            <?php else: ?>
                                <a href="<?php echo e(route( 'toggle' , ['id' => $item->id, 'type' => 'dish'] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-eye-slash"></i></a>
                            <?php endif; ?>
                            <?php echo $__env->make('editor.dish_modal_change', ['menus' => $menus, 'item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <a href="<?php echo e(route( 'destroy' , ['id' => $item->id, 'type' => 'dish'] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-thrash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $items->pages; ?>

        </div>

        
        <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

        
        <script src="/js/app.js"></script>
    </body>
</html>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/editor/dish-edit.blade.php ENDPATH**/ ?>