 <div class="dish">
    <h6><?php echo e($dish->title); ?></h6>
    <p><?php echo e($dish->info); ?></p>
    <p><?php echo e($dish->price); ?> <?php if($dish->beer): ?><span> / <i class="fa-solid fa-beer-mug-empty"></i> <?php echo e($dish->beer); ?> / <i class="fa-solid fa-wine-glass"></i> <?php echo e($dish->wine); ?></span><?php endif; ?></p>

    <?php if($dish->sauce): ?>
        <div class="toppings">
            <h5 class="text-center pb-1 pt-2 cursor-pointer m-0" data-toggle="collapse" href="#collapseSauce<?php echo e($dish->id); ?>" role="button" aria-expanded="false" aria-controls="collapseSauce<?php echo e($dish->id); ?>">Kies hier je saus of topping!<i class="fa-solid fa-circle-plus float-right px-2"></i></h5>
            <div class="collapse" id="collapseSauce<?php echo e($dish->id); ?>">
                <ul class="text-left m-0 mx-3 pb-3 pt-2">
                    <?php echo $__env->make('modules.sauces', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <hr class="dashed">
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/main/modules/dish.blade.php ENDPATH**/ ?>