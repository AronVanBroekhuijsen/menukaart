<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form class="container crud-table p-3" action="<?php echo e(route('change_order', ['type' => $type])); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div>
                <a href="<?php echo e(route('order_view', ['type' => 'menu', 'id' => ''])); ?>" class="btn btn-primary col-2">Terug</a>
                <button href="" type="submit" class="btn btn-success float-right col-2">Opslaan</button>
            </div>
            <div id="sortable" data-type="<?php echo e($type); ?>">
                <?php if($type == 'sub_product'): ?> <?php $items = $items->full_sub_product ?> <?php endif; ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->sub_product): ?> <?php $next_type = 'sub_product' ?> <?php endif; ?>
                    <a class="bg-primary text-secondary card" <?php if($next_type != 'none'): ?> href="<?php echo e(route('order_view', ['type' => $next_type, 'id' => $item->id])); ?>" <?php endif; ?>>
                        <input type="hidden" name="item[<?php echo e($item->id); ?>]" value="<?php echo e($item->order); ?>">
                        <h3 class="spacing small-buttons"><?php echo e($item->title($item->id)); ?></h3>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </form>

        <?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/editor/order_view.blade.php ENDPATH**/ ?>