<label for="category" class="form-label">Categorie</label>
<select name="category" class="form-control dish-category-select" <?php if($item->product_id[0] == '' || $item->product_id[0] == '0'): ?> required <?php endif; ?>>
    <option <?php if($item->product_id[0] == '' || $item->product_id[0] == '0'): ?> value="" <?php else: ?> value="0" <?php endif; ?> >Geen category</option>
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $menu->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $courses->sub_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sub_courses->id); ?>" <?php if(isset($item)): ?> <?php if($sub_courses->id == $item->sub_course_id): ?> selected <?php endif; ?> <?php endif; ?> class="optionParent"><?php echo e($sub_courses->title($sub_courses->id)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH C:\xampp\htdocs\Menukaart\resources\views/editor/dish_category_select.blade.php ENDPATH**/ ?>