<?php $__currentLoopData = $sauces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sauce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($sauce->title($sauce->id)); ?> | + <?php echo e($sauce->price); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/modules/sauces.blade.php ENDPATH**/ ?>