<div class="bg-primary text-secondary card">
    <h3 class="spacing"><?php echo e($course->title); ?></h3>
</div>
<?php echo $__env->renderEach('main.modules.sub_course', $course->sub_courses, 'sub_course'); ?>

<?php /**PATH C:\MAMP\htdocs\Website\resources\views/main/modules/course.blade.php ENDPATH**/ ?>