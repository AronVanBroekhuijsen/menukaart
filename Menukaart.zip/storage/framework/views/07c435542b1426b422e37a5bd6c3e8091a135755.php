<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container crud-table p-3">
            <div class="form-group row">
                <form action="" class="col-10 row">
                    <div class="col-11">
                        <select name="menu" class="form-control custom-select">
                            <option value="">Selecteer Category</option>
                            <option value="0" <?php if(0 == $current): ?>selected <?php endif; ?>>Sub Producten</option>
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($menu->title($menu->id)); ?>" <?php if($menu->title($menu->id) == $current): ?>selected <?php endif; ?> class="optionParent"><?php echo e($menu->title($menu->id)); ?></option>
                                    <?php $__currentLoopData = $menu->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($courses->title($courses->id)); ?>" <?php if($courses->title($courses->id) == $current): ?>selected <?php endif; ?> class="optionSubParent"><?php echo e($courses->title($courses->id)); ?></option>
                                        <?php $__currentLoopData = $courses->sub_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sub_courses->title($sub_courses->id) == ''): ?> <?php continue; ?> <?php endif; ?>
                                            <option value="<?php echo e($sub_courses->title($sub_courses->id)); ?>" <?php if($sub_courses->title($sub_courses->id) == $current): ?>selected <?php endif; ?> class="optionChild"><?php echo e($sub_courses->title($sub_courses->id)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="text" name="search_title" class="submit search_title form-control mt-2" value="<?php echo e($search_title); ?>">
                    </div>

                    <div class="col-1 form-check">
                        <input type="checkbox" name="disabled" class="form-check-input" id="disabled" <?php echo e(($disabled == 'on' ? ' checked' : '')); ?>>
                        <label for="disabled" class="form-check-label">Uit</label>
                    </div>
                </form>

                <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                    <div class="col-2 pl-0">
                        <?php echo $__env->make('editor.dish_modal', $menus, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
                <div class="clearfix"></div>
            </div>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Categorie</th>
                        <th>Titel</th>
                        <th>Info</th>
                        <th>Prijs</th>
                        <th>Prijs2</th>
                        
                        
                        
                        
                        
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php if($item->toggle == 1): ?> class="disabled"<?php endif; ?>>
                        <td><b><?php echo e($item->category($item)); ?></b></td>
                        <?php
                            $title = $item->title($item->id);
                            $info = $item->info($item->id);
                        ?>
                        <td><?php echo e($title->nl); ?></td>
                        <td><?php echo $info->nl; ?></td>
                        <td><?php if($item->price !== '0,00'): ?><?php echo e($item->price); ?> <?php endif; ?></td>
                        <td><?php if($item->price_large !== '0,00'): ?><?php echo e($item->price_large); ?><?php endif; ?></td>
                        
                        
                        
                        
                        
                        <td>
                            <?php if($item->toggle == 1): ?>
                                <a href="<?php echo e(route( 'toggle' , ['id' => $item->id, 'type' => 'dish'] )); ?>" type="submit" class="btn btn-success"><i class="fa-solid fa-eye"></i></a>
                            <?php else: ?>
                                <a href="<?php echo e(route( 'toggle' , ['id' => $item->id, 'type' => 'dish'] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-eye-slash"></i></a>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary changeDishButton" data-toggle="modal" data-target="#changeDish" data-dish-id="<?php echo e($item->id); ?>">
                                    <i class="fa-solid fa-pencil"></i>
                                </button>

                                <a href="<?php echo e(route( 'duplicate_dish' , ['id' => $item->id] )); ?>" class="btn btn-success">
                                    <i class="fa-regular fa-copy"></i>
                                </a>
                                
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <a href="<?php echo e(route( 'destroy_dish' , ['id' => $item->id] )); ?>" class="btn btn-danger" onclick="return confirm('Verwijder <?php echo e($title->nl); ?>?')"><i class="fa-solid fa-trash"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Modal -->
                    <div class="modal fade changeDishMain" id="changeDish" tabindex="-1" role="dialog" aria-labelledby="changeDishLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="changeDishLabel">Product aanpassen</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                </tbody>
            </table>
            <?php echo $items->pages; ?>

        </div>

        <?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/editor/dish-view.blade.php ENDPATH**/ ?>