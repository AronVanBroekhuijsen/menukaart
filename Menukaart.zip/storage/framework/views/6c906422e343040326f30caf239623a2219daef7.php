<div class="product-select">
    <label for="product" class="form-label pt-2">Product</label>
    <select name="products[]" class="form-control dish-product-select" multiple="multiple" required>
        <option value="">Geen product</option>
        <?php $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($dish->id); ?>"  <?php if(isset($item)): ?> <?php if(in_array($dish->id, $item->product_id)): ?> selected <?php endif; ?> <?php endif; ?> class="optionParent"><?php echo e($dish->title($dish->id)->nl ?? $dish->title($dish->id)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/editor/dish_product_select.blade.php ENDPATH**/ ?>