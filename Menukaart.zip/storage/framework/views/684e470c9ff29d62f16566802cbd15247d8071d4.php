<div id="header">
    <h3 class="text-tertiary"><?php echo e($menu->title); ?></h3>
    <h6 class="text-white">bij Restaurant De Haas</h4>

    <?php echo $__env->make('main.modules.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/main/modules/menuheader.blade.php ENDPATH**/ ?>