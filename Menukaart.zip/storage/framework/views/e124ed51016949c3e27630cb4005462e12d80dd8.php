<div>
    <a href="<?php echo e(URL::current()); ?>"><img src="<?php echo e(asset('storage/images/nl_flag.png')); ?>" width="35" height="23"></a>
    <a href="?lang=en"><img src="<?php echo e(asset('storage/images/en_flag.png')); ?>" width="35" height="23"></a>
    <a href="?lang=de"><img src="<?php echo e(asset('storage/images/de_flag.png')); ?>" width="35" height="23"></a>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/modules/language.blade.php ENDPATH**/ ?>