<?php if($sub_course->toggle == 0): ?>

    <?php if($sub_course->image): ?>
        <div class="background-wrapper position-relative">
            <span class="categorie-background" style="background-image: linear-gradient(180deg,#404140 0%,rgba(64,65,64,0.39) 100%),url(<?php echo e(asset('storage/images/uploaded/'. $sub_course->image)); ?>)!important;"></span>
            <span class="add-divider"></span>
    <?php endif; ?>
    <div class="text-primary sub-menu pt-3 <?php if($sub_course->image): ?>all-orange pb-5 <?php endif; ?>">
        <h5 class="spacing"><?php echo e($sub_course->title($sub_course->id)); ?></h5>
        <h6 class="text-white mb-2"><?php echo e($sub_course->sub_title($sub_course->id)); ?></h6>

        <div class="dishes <?php if($sub_course->image): ?>no-shadow <?php endif; ?>">
            <?php echo $__env->renderEach('modules.dish', $sub_course->dishes, 'dish'); ?>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php if($sub_course->image): ?>
        </div>
    <?php endif; ?>
    <img class="m-5" src="<?php echo e(asset('storage/images/ears.png')); ?>">
<?php endif; ?>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/modules/sub_course.blade.php ENDPATH**/ ?>