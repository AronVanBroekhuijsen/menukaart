<?php if($dish->toggle == 0): ?>
    <div class="dish clearfix <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?>my-table row <?php endif; ?> <?php if($dish->image && !$dish->big_description($dish->id)): ?>pb-3 <?php endif; ?>">
        <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?><div class="col"> <?php endif; ?>
            <h6 class="dish-h6">
                <?php if($dish->vos_image == 1): ?><img src="<?php echo e(asset('storage/images/LogoVos.png.webp')); ?>" style="padding: 7px;" alt="Vos ears for the beers"><?php endif; ?>
                <span class="col-6 pl-0"><?php echo e($dish->title($dish->id)); ?></span>
                <?php if($dish->vegan == 1): ?><img src="<?php echo e(asset('storage/images/vega.png')); ?>" style="vertical-align: sub;" alt="vegan"><?php endif; ?>
                <?php if($dish->glute == 1): ?><img src="<?php echo e(asset('storage/images/gluten-free.png')); ?>" style="vertical-align: sub;" alt="gluten"><?php endif; ?>
                <?php if($dish->lactose == 1): ?><img src="<?php echo e(asset('storage/images/lactose-free.png')); ?>" style="vertical-align: sub;" alt="lactose"><?php endif; ?>
                <?php if($dish->big_description($dish->id)): ?>
                    <!-- Button trigger modal -->
                    <span type="button" class="col-6 p-0" data-toggle="modal" data-target="#openDescription<?php echo e($dish->id); ?>">
                        <i class="fa-solid fa-circle-info"></i> <?php echo e($dish->more_info()); ?>

                    </span>

                    <!-- Modal -->
                    <div class="modal fade wrapper" class="openDescription" id="openDescription<?php echo e($dish->id); ?>" tabindex="-1" role="dialog" aria-labelledby="openDescription<?php echo e($dish->id); ?>Label" aria-hidden="true">
                        <div class="modal-dialog modal-xl" role="document">
                            <div class="modal-content">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <i aria-hidden="true" class="fa-solid fa-xmark"></i>
                                </button>
                                <div class="modal-body">
                                    <h3><?php echo e($dish->title($dish->id)); ?></h3>
                                    <h6><?php echo $dish->info($dish->id); ?></h4>
                                    <?php if($dish->image != ''): ?> <img src="<?php echo e(asset('storage/images/uploaded/'. $dish->image)); ?>" alt="Dish image <?php echo e($dish->title($dish->id)); ?>"> <?php endif; ?>
                                    <span style="width:70%;margin:0 15%;"><?php echo $dish->big_description($dish->id); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </h6>
            <?php if($dish->info($dish->id)): ?>
                <span class="dish-p"><?php echo $dish->info($dish->id); ?>

                    <?php if($dish->sub_product): ?><span class="text-tertiary"><?php $__currentLoopData = $dish->sub_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><br>- <?php echo e($sub_product); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><span><?php endif; ?>
                </span>
            <?php endif; ?>
        <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?></div><?php endif; ?>
        <div class="suggestion <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?>col-2 <?php endif; ?>"><?php if($dish->price !== '0,00'): ?><?php echo e($dish->price); ?><?php endif; ?> <?php if($dish->beer_id): ?><span class="dish-span"> / <i class="fa-solid fa-beer-mug-empty"></i> <?php echo e($dish->beer_id); ?> <?php endif; ?> <?php if($dish->wine_id): ?>/ <i class="fa-solid fa-wine-glass"></i> <?php echo e($dish->wine_id); ?></span><?php endif; ?></div>
        <?php if($dish->sub_course->text_small($dish->sub_course->id) != ''): ?>
            <div class="suggestion <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?>col-2 <?php endif; ?>"><?php if($dish->price_large !== '0,00'): ?><?php echo e($dish->price_large); ?><?php endif; ?> </div>
        <?php endif; ?>

        <?php if($dish->sauce): ?>
            <div class="toppings">
                <h5 class="text-center pb-1 pt-2 cursor-pointer m-0" data-toggle="collapse" href="#collapseSauce<?php echo e($dish->id); ?>" role="button" aria-expanded="false" aria-controls="collapseSauce<?php echo e($dish->id); ?>"><?php if(isset($_GET['lang'])): ?> <?php if($_GET['lang'] == 'en'): ?>Choose your sauce or topping here! <?php elseif($_GET['lang'] == 'de'): ?>Wählen Sie hier Ihre Soße oder Ihr Topping!<?php endif; ?> <?php else: ?> Kies hier je saus of topping!<?php endif; ?><i class="fa-solid fa-circle-plus float-right px-2"></i></h5>
                <div class="collapse" id="collapseSauce<?php echo e($dish->id); ?>">
                    <ul class="text-left m-0 mx-3 pb-3 pt-2">
                        <?php echo $__env->make('modules.sauces', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
        <?php if($dish->image && !$dish->big_description($dish->id)): ?>
            <div class="dish-image">
                <span class="title"><?php echo e($dish->title($dish->id)); ?></span>
                <img src="<?php echo e(asset('storage/images/uploaded/'. $dish->image)); ?>" style="max-width: 100%;" alt="Dish image <?php echo e($dish->title($dish->id)); ?>">
            </div>
        <?php endif; ?>
        <hr class="dashed">
    </div>
<?php endif; ?>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/modules/dish.blade.php ENDPATH**/ ?>