<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="container crud-table p-3">
                <div class="form-group row">
                    <div class="col-2 offset-10">
                        <a href="<?php echo e(route( 'register')); ?>" type="submit" class="btn btn-success">Nieuwe gebruiker</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Titel</th>
                            <th>Role</th>
                            <th width="200px">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form id="saveUser" action="<?php echo e(route('save_user', ['id' => $user->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td>
                                    <select name="user_role" class="form-select">
                                        <option value="user" <?php if($user->role == 'user'): ?>selected <?php endif; ?>>Gebruiker</option>
                                        <option value="toggler" <?php if($user->role == 'toggler'): ?>selected <?php endif; ?>>Aan/Uit</option>
                                        <option value="editor" <?php if($user->role == 'editor'): ?>selected <?php endif; ?>>Bewerker</option>
                                        <option value="admin" <?php if($user->role == 'admin'): ?>selected <?php endif; ?>>Beheerder</option>
                                    </select>
                                </td>
                                <td>
                                    <button type="submit" class="btn btn-success"><i class="fa-solid fa-check text-white"></i></button>
                                    <?php if(Auth::user()->role == 'admin'): ?>
                                        <a href="<?php echo e(route( 'destroy_user' , ['id' => $user->id] )); ?>" type="submit" class="btn btn-danger" onclick="return confirm('Verwijder <?php echo e($user->name); ?>?')"><i class="fa-solid fa-trash"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/editor/users.blade.php ENDPATH**/ ?>