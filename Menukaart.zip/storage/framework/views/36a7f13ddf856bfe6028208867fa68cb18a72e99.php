<!-- Button trigger modal -->
<button type="button" class="btn btn-success col-12 add-product" data-toggle="modal" data-target="#addProduct">
    Product toevoegen
</button>

<!-- Modal -->
<div class="modal fade" id="addProduct" tabindex="-1" role="dialog" aria-labelledby="addProductLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addProductLabel">Product toevoegen</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form  id="addProducts" action="<?php echo e(route('store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title" class="form-label">Titel</label>
                        <input name="title" id="title" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="info" class="form-label">Info</label>
                        <input name="info" id="info" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="price" class="form-label">Prijs</label>
                        <input name="price" id="price" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="beer_id" class="form-label">Bier</label>
                        <input name="beer_id" id="beer_id" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="wine_id" class="form-label">Wijn</label>
                        <input name="wine_id" id="wine_id" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="vegan" class="form-label">Vega</label>
                        <input type="hidden"  name="vegan" value="0" >
                        <input name="vegan" value="1" id="vegan" type="checkbox" class="form-check-input">
                    </div>
                    <div class="form-group">
                        <label for="sauce" class="form-label">Saus</label>
                        <input type="hidden"  name="sauce" value="0" >
                        <input name="sauce" value="1" id="sauce" type="checkbox" class="form-check-input">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/modules/product_modal.blade.php ENDPATH**/ ?>