<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Menu</title>

        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

        
        <link rel="stylesheet" href="/css/app.css" />
        <link rel="stylesheet" href="/css/admin.css" />


    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container crud-table p-3">
            <div class="form-group row">
                <div class="col-6">
                    <?php echo $__env->make('editor.side_info', ['side_info' => $side_info], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <?php echo $__env->make('editor.side_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="clearfix"></div>
            </div>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Titel</th>
                        <th>Titel Engels</th>
                        <th>Titel Duits</th>
                        <th width="150px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sides_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr <?php if($side->toggle == 1): ?> class="disabled"<?php endif; ?>>
                            <?php
                                $title = $side->title($side->id);
                            ?>
                            <td><?php echo e($title->nl); ?></td>
                            <td><?php echo e($title->en); ?></td>
                            <td><?php echo e($title->de); ?></td>
                            <td>
                                <?php if($side->toggle == 1): ?>
                                    <a href="<?php echo e(route( 'toggle' , ['id' => $side->id, 'type' => 'side'] )); ?>" type="submit" class="btn btn-success"><i class="fa-solid fa-eye"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(route( 'toggle' , ['id' => $side->id, 'type' => 'side'] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-eye-slash"></i></a>
                                <?php endif; ?>
                                <?php echo $__env->make('editor.side_modal_change', ['side' => $side], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <a href="<?php echo e(route( 'destroy_side' , ['id' => $side->id] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
        <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

        
        <script src="/js/app.js"></script>
    </body>
</html>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/editor/side-view.blade.php ENDPATH**/ ?>