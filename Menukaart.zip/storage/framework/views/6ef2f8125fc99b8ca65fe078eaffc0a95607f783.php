<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
<nav class="nav navbar navbar-expand-md navbar-light bg-white shadow-sm">

    <div class="px-3 w-100">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarToggle">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
            </ul>

            <!-- Middle Side Of Navbar -->
            <ul class="navbar-nav mx-auto custom-nav-links">
                <!-- Authentication Links -->
                <?php if(Auth::user()->role != 'user'): ?>
                    <a class="nav-link" href="<?php echo e(route('dish_view')); ?>">Producten</a>
                    <a class="nav-link" href="<?php echo e(route('category_view')); ?>">Categorien</a>
                    <a class="nav-link" href="<?php echo e(route('sauce_view')); ?>">Sauzen/Toppings</a>
                    <a class="nav-link" href="<?php echo e(route('side_view')); ?>">Bijgerechten</a>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                    <a class="nav-link" href="<?php echo e(route('order_view')); ?>">Volgorde aanpassen</a>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'admin'): ?>
                    <a class="nav-link" href="<?php echo e(route('user_view')); ?>">Gebruikers</a>
                    <a class="nav-link" href="<?php echo e(route('settings')); ?>">Instellingen</a>
                <?php endif; ?>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="mb-4rem"></div>
<?php endif; ?>

<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/main/auth.blade.php ENDPATH**/ ?>