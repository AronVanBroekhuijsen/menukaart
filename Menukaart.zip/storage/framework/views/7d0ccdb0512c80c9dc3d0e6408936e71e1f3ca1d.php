<div>
    <a><img src="<?php echo e(asset('storage/images/nl_flag.png')); ?>" width="35" height="23"></a>
    <a><img src="<?php echo e(asset('storage/images/en_flag.png')); ?>" width="35" height="23"></a>
    <a><img src="<?php echo e(asset('storage/images/de_flag.png')); ?>" width="35" height="23"></a>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/main/modules/language.blade.php ENDPATH**/ ?>