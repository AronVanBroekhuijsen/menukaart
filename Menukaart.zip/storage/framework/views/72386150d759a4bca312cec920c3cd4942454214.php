<?php if($sub_course->toggle == 0): ?>

    <?php if($sub_course->image): ?>
        <div class="background-wrapper position-relative">
            <span class="categorie-background" style="background-image: linear-gradient(180deg,#697353 0%,rgba(64,65,64,0.39) 100%),url(<?php echo e(asset('storage/images/uploaded/'. $sub_course->image)); ?>)!important;"></span>
            <span class="add-divider"></span>
    <?php endif; ?>
    <div class="tertairy-bright sub-menu mb-5 <?php if($sub_course->image): ?>pb-5 <?php endif; ?>">
        <h5 class="spacing"><?php echo e($sub_course->title($sub_course->id)); ?></h5>
        <h6 class="text-white"><?php echo e($sub_course->sub_title($sub_course->id)); ?></h6>

        <img class="mx-5 mb-1 ears" src="<?php echo e(asset('storage/images/ears.png')); ?>" alt="Divider image vos ears">

        <div class="dishes <?php if($sub_course->image): ?>no-shadow <?php endif; ?>">
            <?php if($sub_course->text_small($sub_course->id) != ''): ?>
                <div class="multiple_price m-0 row">
                    <span class="col-8"></span>
                    <span class="col-2"><?php echo e($sub_course->text_small($sub_course->id)); ?></span>
                    <span class="col-2"><?php echo e($sub_course->text_large($sub_course->id)); ?></span>
                </div>
            <?php endif; ?>
            <?php echo $__env->renderEach('modules.dish', $sub_course->dishes, 'dish'); ?>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php if($sub_course->image): ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Menukaart\resources\views/modules/sub_course.blade.php ENDPATH**/ ?>