<div class="text-primary sub-menu">
    <h5 class="spacing"><?php echo e($sub_course->title); ?></h5>
    <span><?php echo e($sub_course->sub_title); ?></span>

    <div class="dishes">
        <?php echo $__env->renderEach('main.modules.dish', $sub_course->dishes, 'dish'); ?>
    </div>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/main/modules/sub_course.blade.php ENDPATH**/ ?>