
    <div id="cards" class="small row m-0 sticky-main">
        <?php echo $__env->renderEach('modules.card', $menus, 'card'); ?>
        <div class="clearfix"></div>
    </div>

    <h1 class="text-tertiary"><?php echo e($menu->title($menu->id)); ?></h1>
    <h6 class="text-white">bij Restaurant De Haas</h4>

    <?php echo $__env->make('modules.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="sticky-sub">
        <div class="container">
            <div id="cards" class="small grey row px-0 px-md-4">
                <?php echo $__env->renderEach('modules.card', $menu->courses, 'card'); ?>
            </div>
        </div>
    </div>
    <div class="sticky-shadow"></div>
    <div class="shadow-cover"></div>


    <?php if($menu->id != $menu->drinkmenu()): ?>
    <div class="allergy clearfix">
        <div class="float-left">
            <h4>Allergenen informatie</h4>
            <p class="">
                Alle gerechten kunnen sporen bevatten van diverse allergenen. Indien u een allergie hebt, moet u dit altijd duidelijk kenbaar maken bij ons personeel. Wij zullen uw gerecht dan met extra zorg (apart/gescheiden) bereiden.
            </p>
        </div>
        <div class="float-right">
            <img src="<?php echo e(asset('storage/images/Allergenen-1.png')); ?>" alt="Allergic picture">
        </div>
    </div>
    <h6 class="text-white">All onze gerechten met een <img src="<?php echo e(asset('storage/images/vega.png')); ?>" style="vertical-align: sub;" alt="Vega Icon"> zijn vegetarisch!</h6>
    <?php endif; ?>
    
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/testmenu.restaurantdehaas.nl/resources/views/modules/menuheader.blade.php ENDPATH**/ ?>