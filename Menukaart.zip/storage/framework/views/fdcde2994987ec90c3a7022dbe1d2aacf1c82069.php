<div>
    <a href="<?php echo e(URL::current()); ?>"><img alt="nederland-vlag" src="<?php echo e(asset('storage/images/nl_flag.png')); ?>" height="23"></a>
    <a href="?lang=en"><img alt="engelse-vlag" src="<?php echo e(asset('storage/images/en_flag.png')); ?>" height="23"></a>
    <a href="?lang=de"><img alt="duitse-vlag" src="<?php echo e(asset('storage/images/de_flag.png')); ?>" height="23"></a>
</div>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/testmenu.restaurantdehaas.nl/resources/views/modules/language.blade.php ENDPATH**/ ?>