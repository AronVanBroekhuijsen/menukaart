
    <div id="cards" class="small row m-0 sticky-main">
        <?php echo $__env->renderEach('modules.card', $menus, 'card'); ?>
        <div class="clearfix"></div>
    </div>

    <h3 class="text-tertiary"><?php echo e($menu->title($menu->id)); ?></h3>
    <h6 class="text-white">bij Restaurant De Haas</h4>

    <?php echo $__env->make('modules.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="sticky-sub">
        <div class="container">
            <div id="cards" class="small grey row">
                <?php echo $__env->renderEach('modules.card', $menu->courses, 'card'); ?>
            </div>
        </div>
    </div>

    <div class="allergy">
        <div class="float-left">
            <h4>Allergenen informatie</h4>
            <p class="">
                Alle gerechten kunnen sporen bevatten van diverse allergenen. Indien u een allergie hebt, moet u dit altijd duidelijk kenbaar maken bij ons personeel. Wij zullen uw gerecht dan met extra zorg (apart/gescheiden) bereiden.
            </p>
        </div>
        <div class="float-right">
            <img src="<?php echo e(asset('storage/images/Allergenen-1.png')); ?>">
        </div>
    </div>
    <h6 class="text-white">All onze gerechten met een <img src="<?php echo e(asset('storage/images/VegaLogo.png')); ?>" width="22" height="16" style="vertical-align: baseline;"> zijn vegetarisch!</h6>

<?php /**PATH C:\MAMP\htdocs\Website\resources\views/modules/menuheader.blade.php ENDPATH**/ ?>