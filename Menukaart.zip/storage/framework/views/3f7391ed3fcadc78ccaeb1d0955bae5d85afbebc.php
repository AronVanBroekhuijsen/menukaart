<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
<nav class="nav navbar navbar-expand-md navbar-light bg-white shadow-sm">

    <div class="container">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <?php if(Auth::user()->role != 'user'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('dish_view')); ?>">Producten bekijken</a>
                            <a class="dropdown-item" href="<?php echo e(route('category_view')); ?>">Categorien bekijken</a>
                            <a class="dropdown-item" href="<?php echo e(route('sauce_view')); ?>">Sauzen/Toppings bekijken</a>
                            <a class="dropdown-item" href="<?php echo e(route('side_view')); ?>">Bijgerechten</a>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('user_view')); ?>">Gebruikers</a>
                            <a class="dropdown-item" href="<?php echo e(route('settings')); ?>">Instellingen</a>
                        <?php endif; ?>

                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="mb-4rem"></div>
<?php endif; ?>

<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/testmenu.restaurantdehaas.nl/resources/views/main/auth.blade.php ENDPATH**/ ?>