<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container crud-table p-3">
            <div class="form-group row">
                <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                    <div class="col-6">
                        <?php echo $__env->make('editor.side_info', ['side_info' => $side_info], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                    <div class="col-6">
                        <?php echo $__env->make('editor.side_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
                <div class="clearfix"></div>
            </div>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Titel</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sides_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr <?php if($side->toggle == 1): ?> class="disabled"<?php endif; ?>>
                            <?php
                                $title = $side->title($side->id);
                            ?>
                            <td><?php echo e($title->nl); ?></td>
                            <td>
                                <?php if($side->toggle == 1): ?>
                                    <a href="<?php echo e(route( 'toggle' , ['id' => $side->id, 'type' => 'side'] )); ?>" type="submit" class="btn btn-success"><i class="fa-solid fa-eye"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(route( 'toggle' , ['id' => $side->id, 'type' => 'side'] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-eye-slash"></i></a>
                                <?php endif; ?>
                                <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                                    <?php echo $__env->make('editor.side_modal_change', ['side' => $side], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <a href="<?php echo e(route( 'destroy_side' , ['id' => $side->id] )); ?>" type="submit" class="btn btn-danger" onclick="return confirm('Verwijder <?php echo e($title->nl); ?>?')"><i class="fa-solid fa-trash"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/editor/side-view.blade.php ENDPATH**/ ?>