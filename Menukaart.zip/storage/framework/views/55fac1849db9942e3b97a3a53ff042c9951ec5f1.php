<div id="dranken" class="bg-primary text-secondary card clickable">
    <h3><?php echo e($card); ?></h3>
    <span>Frisdranken - Bierkaart - Wijnkaart - Koffie & thee</span>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/menu/modules/card.blade.php ENDPATH**/ ?>