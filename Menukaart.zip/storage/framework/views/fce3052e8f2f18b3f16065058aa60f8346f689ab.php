<?php if($dish->toggle == 0): ?>
    <div class="dish <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?>my-table row <?php endif; ?>">
        <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?><div class="col-10"><?php endif; ?>
            <h6>
                <?php echo e($dish->title($dish->id)); ?>

                <?php if($dish->vegan == 1): ?><img src="<?php echo e(asset('storage/images/VegaLogo.png')); ?>" width="22" height="16" style="vertical-align: baseline;"><?php endif; ?>
                <?php if($dish->glute == 1): ?><img src="<?php echo e(asset('storage/images/gluten-free.png')); ?>" width="30" height="30" style="vertical-align: baseline;"><?php endif; ?>
                <?php if($dish->lactose == 1): ?><img src="<?php echo e(asset('storage/images/lactose-free.png')); ?>" width="30" height="30" style="vertical-align: baseline;"><?php endif; ?>
            </h6>
            <?php if($dish->info($dish->id)): ?><p><?php echo $dish->info($dish->id); ?></p><?php endif; ?>
        <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?></div><?php endif; ?>
        <div class="suggestion <?php if($dish->sub_course->course->menu_id == $dish->drinkmenu()): ?>col-2 <?php endif; ?>"><?php echo e($dish->price); ?> <?php if($dish->beer_id): ?><span> / <i class="fa-solid fa-beer-mug-empty"></i> <?php echo e($dish->beer_id); ?> <?php endif; ?> <?php if($dish->wine_id): ?>/ <i class="fa-solid fa-wine-glass"></i> <?php echo e($dish->wine_id); ?></span><?php endif; ?></div>

        <?php if($dish->sauce): ?>
            <div class="toppings">
                <h5 class="text-center pb-1 pt-2 cursor-pointer m-0" data-toggle="collapse" href="#collapseSauce<?php echo e($dish->id); ?>" role="button" aria-expanded="false" aria-controls="collapseSauce<?php echo e($dish->id); ?>">Kies hier je saus of topping!<i class="fa-solid fa-circle-plus float-right px-2"></i></h5>
                <div class="collapse" id="collapseSauce<?php echo e($dish->id); ?>">
                    <ul class="text-left m-0 mx-3 pb-3 pt-2">
                        <?php echo $__env->make('modules.sauces', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
        <?php if($dish->image): ?>
            <div class="dish-image">
                <img src="<?php echo e(asset('storage/images/uploaded/'. $dish->image)); ?>">
            </div>
        <?php endif; ?>
        <hr class="dashed">
    </div>
<?php endif; ?>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/modules/dish.blade.php ENDPATH**/ ?>