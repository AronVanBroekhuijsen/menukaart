<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container crud-table p-3">
            <div class="form-group row">
                <form action="" class="col-10">
                    <select name="menu" class="form-control custom-select">
                        <option value="">Alles</option>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($menu->title($menu->id)->nl); ?>" <?php if($menu->title($menu->id)->nl == $current): ?>selected <?php endif; ?> class="optionParent"><?php echo e($menu->title($menu->id)->nl); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>

                <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                    <div class="col-2 pl-0">
                        <?php echo $__env->make('editor.category_modal', $menus, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
                <div class="clearfix"></div>
            </div>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Details</th>
                        <th width="200px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($item->type); ?><?php if($item->toggle == 1 || $item->parent_toggle == 1): ?> disabled <?php endif; ?>" >
                        <?php
                            $title = $item->title($item->id);
                            $sub_title = $item->sub_title($item->id);
                        ?>
                        <td><div></div><?php echo e($title->nl); ?></td>
                        <td><?php echo e($sub_title->nl); ?></td>
                        <td>
                        
                        <?php if($item->toggle == 1): ?>
                            <a href="<?php echo e(route( 'toggle' , ['id' => $item->id, 'type' => $item->type] )); ?>" type="submit" class="btn btn-success"><i class="fa-solid fa-eye"></i></a>
                        <?php else: ?>
                            <a href="<?php echo e(route( 'toggle' , ['id' => $item->id, 'type' => $item->type] )); ?>" type="submit" class="btn btn-danger"><i class="fa-solid fa-eye-slash"></i></a>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == 'editor' || Auth::user()->role == 'admin'): ?>
                            <?php echo $__env->make('editor.category_modal_change', ['category' => $item, 'i', $i++], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <a href="<?php echo e(route('destroy_category', ['id' => $item->id, 'type' => $item->type])); ?>" type="submit" class="btn btn-danger" onclick="return confirm('Verwijder <?php echo e($title->nl); ?>?')"><i class="fa-solid fa-trash"></i></a>

                            <?php if($item->type == 'sub_courses'): ?>
                                <a href="<?php echo e(route( 'duplicate_category' , ['id' => $item->id, 'type' => $item->type] )); ?>" class="btn btn-success">
                                    <i class="fa-regular fa-copy"></i>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $items->pages; ?>

        </div>

        <?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/editor/category-view.blade.php ENDPATH**/ ?>