<?php if(isset($card->menu_id)): ?><div class="col-3 p-0 m-auto card-button"><?php endif; ?>
    <div <?php if(isset($card->menu_id)): ?>class="scroll-to bg-primary text-secondary card " href="#<?php echo e(preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '_', $card->title($card->id)))); ?>" <?php else: ?> id="<?php echo e($card->title($card->id)); ?>" href="/app/<?php echo e($card->title($card->id)); ?>/<?php echo e($card->id); ?><?php if(isset($_GET['lang'])): ?>?lang=<?php echo e($_GET['lang']); ?><?php endif; ?>" class="bg-primary text-secondary card link col"<?php endif; ?>>
        <h3 class="spacing small-buttons"><?php echo e($card->title($card->id)); ?></h3>
        <span><?php echo e($card->sub_title($card->id)); ?></span>
    </div>
<?php if(isset($card->menu_id)): ?></div><?php endif; ?>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/modules/card.blade.php ENDPATH**/ ?>