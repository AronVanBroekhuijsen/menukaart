<?php $__currentLoopData = $sauces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sauce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="sauce-li"><?php echo e($sauce->title($sauce->id)); ?> | + <?php echo e($sauce->price); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/modules/sauces.blade.php ENDPATH**/ ?>