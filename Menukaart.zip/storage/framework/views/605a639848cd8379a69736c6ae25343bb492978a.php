<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="antialiased">

        <?php echo $__env->make('main.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container crud-table p-3">
            <form  id="saveSettings" action="<?php echo e(route('save_settings')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="col-3">Instellingen</th>
                            <th class="col-7"></th>
                            <th><button href="" type="submit" class="btn btn-success w-100">Opslaan</i></button></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Drankenkaart</td>
                            <td>
                                <div class="form-group">
                                    <select name="drinkmenu" class="form-control settings-select">
                                        <option value="">Geen category</option>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($menu->id); ?>" <?php if($menu->id == $settings->drinkmenu): ?>selected <?php endif; ?> class="optionParent"><?php echo e($menu->title($menu->id)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Wijn</td>
                            <td>
                                <div class="form-group">
                                    <select name="wine_category" class="form-control settings-select">
                                        <option value="">Geen category</option>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $menu->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($courses->id); ?>" <?php if($courses->id == $settings->wine): ?>selected <?php endif; ?> class="optionParent"><?php echo e($courses->title($courses->id)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Bier</td>
                            <td>
                                <div class="form-group">
                                    <select name="beer_category" class="form-control settings-select">
                                        <option value="">Geen category</option>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $menu->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($courses->id); ?>" <?php if($courses->id == $settings->beer): ?>selected <?php endif; ?> class="optionParent"><?php echo e($courses->title($courses->id)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Hoofdgerechten</td>
                            <td>
                                <div class="form-group">
                                    <select name="maincourses" class="form-control settings-select">
                                        <option value="">Geen category</option>
                                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $menu->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($courses->id); ?>" <?php if($courses->id == $settings->maincourses): ?>selected <?php endif; ?> class="optionParent"><?php echo e($courses->title($courses->id)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>

        <?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /var/www/vhosts/restaurantdehaas.nl/menu.restaurantdehaas.nl/resources/views/editor/settings.blade.php ENDPATH**/ ?>