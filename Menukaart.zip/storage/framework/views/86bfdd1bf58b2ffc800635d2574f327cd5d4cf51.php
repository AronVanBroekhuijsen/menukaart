<div id="<?php echo e($card->title); ?>" href="/app/<?php echo e($card->title); ?>/<?php echo e($card->id); ?>" class="bg-primary text-secondary card link">
    <h3 class="spacing"><?php echo e($card->title); ?></h3>
    <span><?php echo e($card->sub_title); ?></span>
</div>
<?php /**PATH C:\MAMP\htdocs\Website\resources\views/main/modules/card.blade.php ENDPATH**/ ?>